# package_name

Description. 
The package package_name is used to:
	- Processing images
	- Combination Images
	- TRansformation Images

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install package_name
```

```

## Author

Cristiano Cezar

## License
[MIT](https://choosealicense.com/licenses/mit/)