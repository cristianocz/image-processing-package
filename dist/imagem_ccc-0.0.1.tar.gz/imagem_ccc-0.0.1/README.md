# package_name

Description. 
The package IMAGEM_CCC is used to:
	- Processing images
	- Combination Images
	- TRansformation Images

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install IMAGEM_CCC

```bash
pip install IMAGEM_CCC
```

```

## Author

Cristiano Cezar

## License
[MIT](https://choosealicense.com/licenses/mit/)